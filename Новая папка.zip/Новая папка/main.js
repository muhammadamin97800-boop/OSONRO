





    const tools = [
        ["Kalkulyator","🧮","Hisob-kitoblar"],
        ["Ob-havo","🌤️","Ob-havo ma'lumoti"],
        ["Tarjimon","🌍","Matn tarjimasi"],
        ["Kalendar","📅","Sanalar"],
        ["Taymer","⏱️","Vaqtni sanash"],
        ["Sekundomer","⏰","Vaqt o‘lchash"],
        ["Parol generatori","🔐","Yangi parol"],
        ["QR kod","📱","QR kod yaratish"],
        ["Matn hisoblagich","📝","So‘z va harflar"],
        ["Rang tanlagich","🎨","Ranglar"],
   ["IELTS Preparation", "🎓", "IELTS exam preparation"],
        ["Vazifalar","✅","Vazifalar ro‘yxati"],
        ["Matematika testi","🧠","Bilimingizni sinang"],
        ["Kunlik reja","📖","Kunlik rejalaringiz"],
        ["Valyuta","💱","Valyuta konvertori"],
        ["Yosh hisoblagich","🎂","Yoshingizni hisoblang"],
        ["Eslatmalar","🔔","Eslatma yozing"],
        ["Kod muharriri","💻","HTML kod sinovi"],
        ["JSON formatlagich","📋","JSON tekshirish"],
        ["Tasodifiy son","🎲","Son chiqarish"],
        ["Internet qidiruv","🔎","Internetdan qidirish"],
        ["Foiz hisoblagich","📊","Foiz hisoblash"],
        ["Ovoz yozish","🎙️","Ovoz yozish"],
        ["Sevimlilar","⭐","Saqlangan vositalar"],
        ["Profil","👤","Profil ma'lumoti"],
        ["Soat","🕒","Hozirgi vaqt"],
        ["Rasm tanlash","🖼️","Rasmni ko‘rish"],
        ["Birlik konvertori","📏","Uzunlik va og‘irlik"],
        ["So‘z sanagich","🔤","Belgilarni sanash"]
    ];

    const list = document.querySelector("#tools");
    const search = document.querySelector("#search");
    const workspace = document.querySelector("#workspace");
    const content = document.querySelector("#workContent");
    const title = document.querySelector("#workTitle");

    tools.forEach((tool, i) => {
        const colors = [
            ["#4935a8", "#9c72ff"],
            ["#087eaa", "#56d5ed"],
            ["#7541a8", "#d18aff"],
            ["#087d70", "#5ce0b5"],
            ["#a45a22", "#ffbd69"],
            ["#3453a8", "#829aff"]
        ];

        const [c1, c2] = colors[i % colors.length];

        const svg = `
            <svg xmlns="http://www.w3.org/2000/svg" width="600" height="300">
                <defs>
                    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%" stop-color="${c1}"/>
                        <stop offset="100%" stop-color="${c2}"/>
                    </linearGradient>
                </defs>
                <rect width="600" height="300" rx="30" fill="url(#g)"/>
                <circle cx="500" cy="40" r="110" fill="white" opacity=".10"/>
                <circle cx="80" cy="280" r="100" fill="white" opacity=".10"/>
                <text x="300" y="185" font-size="125"
                    text-anchor="middle">${tool[1]}</text>
            </svg>
        `;

        const image = "data:image/svg+xml;charset=UTF-8," +
            encodeURIComponent(svg);

        list.innerHTML += `
            <div class="tool" data-name="${tool[0].toLowerCase()}">
                <img class="tool-image" src="${image}" alt="${tool[0]}">
                <h3>${tool[0]}</h3>
                <p>${tool[2]}</p>
            </div>
        `;
    });

    search.addEventListener("input", () => {
        document.querySelectorAll(".tool").forEach(card => {
            card.style.display = card.dataset.name.includes(search.value.toLowerCase())
                ? "block" : "none";
        });
    });

    document.querySelector("#themeBtn").onclick = () => {
        document.body.classList.toggle("light");
    };

    document.querySelector("#closeWork").onclick = () => {
        workspace.style.display = "none";
    };

    function show(name, html) {
        title.textContent = name;
        content.innerHTML = html;
        workspace.style.display = "block";
        workspace.scrollIntoView({behavior:"smooth"});
    }

    document.querySelectorAll(".tool").forEach(card => {
        card.addEventListener("click", () => openTool(card.dataset.name));
    });


    let osonroAIHistory = [];

    function setupOSONROAI() {
        const form = document.querySelector("#aiForm");
        const input = document.querySelector("#aiInput");
        const messagesBox = document.querySelector("#aiMessages");

        osonroAIHistory = [];

        form.addEventListener("submit", async (e) => {
            e.preventDefault();

            const text = input.value.trim();
            if (!text) return;

            osonroAIHistory.push({
                role: "user",
                content: text
            });

            const userMessage = document.createElement("div");
            userMessage.className = "ai-message ai-user";
            userMessage.textContent = text;
            messagesBox.appendChild(userMessage);

            input.value = "";

            const loading = document.createElement("div");
            loading.className = "ai-message ai-bot";
            loading.textContent = "OSONRO AI yozmoqda...";
            messagesBox.appendChild(loading);

            try {
                const response = await fetch("/api/chat", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        messages: osonroAIHistory
                    })
                });

                const data = await response.json();

                loading.remove();

                if (!response.ok) {
                    throw new Error(data.error || "Xatolik");
                }

                const answer = data.reply || "Javob kelmadi";

                osonroAIHistory.push({
                    role: "assistant",
                    content: answer
                });

                const botMessage = document.createElement("div");
                botMessage.className = "ai-message ai-bot";
                botMessage.textContent = answer;
                messagesBox.appendChild(botMessage);

            } catch (error) {
                loading.textContent = "Xatolik: " + error.message;
            }

            messagesBox.scrollTop = messagesBox.scrollHeight;
        });
    }


    function openTool(name) {
        const field = '<input id="v" placeholder="Qiymat kiriting">';
        const button = '<button id="go">Hisoblash</button>';
        const result = '<div class="result" id="result">Natija shu yerda chiqadi</div>';


        

        if (name === "kalkulyator") {
            show("🧮 Kalkulyator", `
                <input id="calc" placeholder="0" readonly>
                <div class="calc-grid">
                    ${["7","8","9","/","4","5","6","*","1","2","3","-","C","0",".","+","(",")","⌫","="].map(x => `<button data-c="${x}">${x}</button>`).join("")}
                </div>
            `);
            


            content.querySelectorAll("[data-c]").forEach(b => {
                b.onclick = () => {
                    const d = document.querySelector("#calc");
                    const x = b.dataset.c;

                    if (x === "C") d.value = "";
                    else if (x === "⌫") d.value = d.value.slice(0, -1);
                    else if (x === "=") {
                        try {
                            if (!/^[0-9+\-*/().\s]+$/.test(d.value)) throw Error();
                            const r = Function('"use strict";return (' + d.value + ')')();
                            if (!Number.isFinite(r)) throw Error();
                            d.value = r;
                        } catch {
                            d.value = "Xatolik";
                        }
                    } else {
                        if (d.value === "Xatolik") d.value = "";
                        d.value += x;
                    }
                };
            });
        }



        else if (name === "taymer") {
            show("⏱️ Taymer", `
                <input id="seconds" type="number" placeholder="Sekund kiriting">
                <h1 id="timer">00:00</h1>
                <button id="start">Boshlash</button>
                <button id="stop">To‘xtatish</button>
                <button id="reset">Qayta boshlash</button>
            `);
            let t, remaining = 0;
            const out = document.querySelector("#timer");
            function update() {
                out.textContent = Math.floor(remaining/60).toString().padStart(2,"0")+":"+ (remaining%60).toString().padStart(2,"0");
            }
            document.querySelector("#start").onclick = () => {
                if (t) return;
                if (remaining <= 0) remaining = Math.max(0, Number(document.querySelector("#seconds").value) || 0);
                update();
                t = setInterval(() => {
                    if (remaining > 0) remaining--;
                    update();
                    if (remaining === 0) {
                        clearInterval(t);
                        t = null;
                        alert("Taymer tugadi!");
                    }
                },1000);
            };
            document.querySelector("#stop").onclick = () => { clearInterval(t); t=null; };
            document.querySelector("#reset").onclick = () => { clearInterval(t); t=null; remaining=0; update(); };
        }

        

        else if (name === "sekundomer") {
            show("⏰ Sekundomer", `
                <h1 id="watch">00:00:00</h1>
                <button id="start">Boshlash</button>
                <button id="stop">To‘xtatish</button>
                <button id="reset">Tozalash</button>
            `);
            let sec=0, t;
            function update() {
                document.querySelector("#watch").textContent =
                    [Math.floor(sec/3600),Math.floor(sec/60)%60,sec%60].map(n=>String(n).padStart(2,"0")).join(":");
            }
            document.querySelector("#start").onclick=()=>{if(!t)t=setInterval(()=>{sec++;update();},1000);};
            document.querySelector("#stop").onclick=()=>{clearInterval(t);t=null;};
            document.querySelector("#reset").onclick=()=>{clearInterval(t);t=null;sec=0;update();};
        }

        else if (name === "parol generatori") {
            show("🔐 Parol generatori", `
                <input type="number" id="size" value="16" min="4" max="64">
                <button id="go">Parol yaratish</button>
                <div class="result" id="result"></div>
                <button id="copy">Nusxa olish</button>
            `);
            document.querySelector("#go").onclick=()=>{
                const chars="abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%";
                const n=Math.min(64,Math.max(4,Number(document.querySelector("#size").value)||16));
                let p="";
                for(let i=0;i<n;i++) p+=chars[Math.floor(Math.random()*chars.length)];
                document.querySelector("#result").textContent=p;
            };
            document.querySelector("#copy").onclick=()=>navigator.clipboard.writeText(document.querySelector("#result").textContent);
        }

        else if (name === "matn hisoblagich" || name === "so‘z sanagich") {
            show("📝 Matn hisoblagich", `
                <textarea id="words" rows="7" placeholder="Matn yozing..."></textarea>
                <div class="result" id="result">So‘zlar: 0 | Harflar: 0 | Belgilar: 0</div>
            `);
            document.querySelector("#words").oninput=e=>{
                const s=e.target.value;
                const count=s.trim()?s.trim().split(/\s+/).length:0;
                document.querySelector("#result").textContent=`So‘zlar: ${count} | Harflar: ${s.replace(/\s/g,"").length} | Belgilar: ${s.length}`;
            };
        }

        else if (name === "rang tanlagich") {
            show("🎨 Rang tanlagich", `
                <input type="color" id="color" value="#8b7cff">
                <div class="result" id="result">#8b7cff</div>
                <button id="copy">Rang kodini nusxalash</button>
            `);
            document.querySelector("#color").oninput=e=>document.querySelector("#result").textContent=e.target.value;
            document.querySelector("#copy").onclick=()=>navigator.clipboard.writeText(document.querySelector("#result").textContent);
        }

        else if (name === "vazifalar" || name === "kunlik reja") {
            show("✅ Vazifalar", `
                <input id="task" placeholder="Vazifa yozing...">
                <button id="add">Qo‘shish</button>
                <div id="tasks"></div>
            `);
            const saved=JSON.parse(localStorage.getItem("osonro_tasks")||"[]");
            function draw(){
                document.querySelector("#tasks").innerHTML=saved.map((x,i)=>`
                    <div class="result">
                        <label><input type="checkbox" ${x.done?"checked":""} data-check="${i}" style="width:auto">${x.text}</label>
                        <button data-delete="${i}">O‘chirish</button>
                    </div>`).join("");
                document.querySelectorAll("[data-check]").forEach(b=>b.onchange=()=>{saved[b.dataset.check].done=b.checked;save();draw();});
                document.querySelectorAll("[data-delete]").forEach(b=>b.onclick=()=>{saved.splice(b.dataset.delete,1);save();draw();});
            }
            function save(){localStorage.setItem("osonro_tasks",JSON.stringify(saved));}
            document.querySelector("#add").onclick=()=>{
                const v=document.querySelector("#task").value.trim();
                if(v){saved.push({text:v,done:false});save();draw();document.querySelector("#task").value="";}
            };
            draw();
        }

        else if (name === "kalendar") {
            show("📅 Kalendar", `<input type="date" id="date"><div id="result" class="result"></div>`);
            document.querySelector("#date").value=new Date().toISOString().slice(0,10);
            document.querySelector("#date").onchange=e=>document.querySelector("#result").textContent=new Date(e.target.value+"T12:00:00").toLocaleDateString("uz-UZ",{dateStyle:"full"});
            document.querySelector("#date").dispatchEvent(new Event("change"));
        }

        else if (name === "yosh hisoblagich") {
            show("🎂 Yosh hisoblagich", `<input type="date" id="birth">${button}${result}`);
            document.querySelector("#go").onclick=()=>{
                const d=new Date(document.querySelector("#birth").value);
                if(!document.querySelector("#birth").value)return;
                let age=new Date().getFullYear()-d.getFullYear();
                const now=new Date();
                if(now<new Date(now.getFullYear(),d.getMonth(),d.getDate()))age--;
                document.querySelector("#result").textContent="Sizning yoshingiz: "+age;
            };
        }

        else if (name === "tasodifiy son") {
            show("🎲 Tasodifiy son", `
                <input id="min" type="number" placeholder="Eng kichik son">
                <input id="max" type="number" placeholder="Eng katta son">
                <button id="go">Son chiqarish</button>${result}
            `);
            document.querySelector("#go").onclick=()=>{
                const a=Number(document.querySelector("#min").value),b=Number(document.querySelector("#max").value);
                if(!document.querySelector("#min").value||!document.querySelector("#max").value||b<a){document.querySelector("#result").textContent="Sonlarni to‘g‘ri kiriting";return;}
                document.querySelector("#result").textContent=Math.floor(Math.random()*(b-a+1))+a;
            };
        }

        else if (name === "foiz hisoblagich") {
            show("📊 Foiz hisoblagich", `
                <input id="number" type="number" placeholder="Son">
                <input id="percent" type="number" placeholder="Foiz">
                <button id="go">Hisoblash</button>${result}
            `);
            document.querySelector("#go").onclick=()=>{
                document.querySelector("#result").textContent=Number(document.querySelector("#number").value)*Number(document.querySelector("#percent").value)/100;
            };
        }

        else if (name === "birlik konvertori") {
            show("📏 Birlik konvertori", `
                <input id="amount" type="number" placeholder="Miqdor">
                <select id="unit"><option value="1000">Kilometr → metr</option><option value="0.001">Metr → kilometr</option><option value="100">Metr → santimetr</option><option value="0.01">Santimetr → metr</option><option value="1000">Kilogramm → gramm</option></select>
                <button id="go">Hisoblash</button>${result}
            `);
            document.querySelector("#go").onclick=()=>document.querySelector("#result").textContent=Number(document.querySelector("#amount").value)*Number(document.querySelector("#unit").value);
        }

        else if (name === "json formatlagich") {
            show("📋 JSON formatlagich", `
                <textarea id="json" rows="7" placeholder='{"name":"Ali"}'></textarea>
                <button id="go">Tekshirish</button>${result}
            `);
            document.querySelector("#go").onclick=()=>{
                try{document.querySelector("#result").textContent=JSON.stringify(JSON.parse(document.querySelector("#json").value),null,2);}
                catch{document.querySelector("#result").textContent="JSON xato!";}
            };
        }

        else if (name === "qr kod") {
            show("📱 QR kod", `
                <input id="qrText" placeholder="Matn yoki havola kiriting">
                <button id="go">QR yaratish</button>
                <div class="result" id="result"></div>
            `);
            document.querySelector("#go").onclick=()=>{
                const value=document.querySelector("#qrText").value.trim();
                if(!value)return;
                const img=document.createElement("img");
                img.alt="QR kod";
                img.width=200;
                img.src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data="+encodeURIComponent(value);
                const box=document.querySelector("#result");
                box.replaceChildren(img);
            };
        }

        else if (name === "internet qidiruv") {
            show("🔎 Internet qidiruv", `
                <input id="query" placeholder="Nima qidiramiz?">
                <button id="go">Qidirish</button>
            `);
            document.querySelector("#go").onclick=()=>{
                const q=document.querySelector("#query").value.trim();
                if(q)window.open("https://www.google.com/search?q="+encodeURIComponent(q),"_blank","noopener");
            };
        }

        else if (name === "rasm tanlash") {
            show("🖼️ Rasm tanlash", `
                <input type="file" id="imageFile" accept="image/*">
                <img id="preview" style="max-width:100%;margin-top:15px">
            `);
            document.querySelector("#imageFile").onchange=e=>{
                const f=e.target.files[0];
                if(f)document.querySelector("#preview").src=URL.createObjectURL(f);
            };
        }

        else if (name === "soat") {
            show("🕒 Soat", `<h1 id="clock"></h1><div class="result" id="date"></div>`);
            const tick=()=>{
                document.querySelector("#clock").textContent=new Date().toLocaleTimeString("uz-UZ");
                document.querySelector("#date").textContent=new Date().toLocaleDateString("uz-UZ",{dateStyle:"full"});
            };
            tick();
            const id=setInterval(()=>{if(!workspace.isConnected||workspace.style.display==="none"){clearInterval(id);return;}tick();},1000);
        }

        else if (name === "profil") {
            show("👤 Profil", `
                <input id="profileName" placeholder="Ismingiz">
                <button id="save">Saqlash</button>
                <div id="result" class="result"></div>
            `);
            document.querySelector("#profileName").value=localStorage.getItem("osonro_name")||"";
            document.querySelector("#save").onclick=()=>{
                localStorage.setItem("osonro_name",document.querySelector("#profileName").value);
                document.querySelector("#result").textContent="Profil saqlandi!";
            };
        }

    
    else if (name === "sevimlilar") {
        let favorites = JSON.parse(localStorage.getItem("osonro_favorites") || "[]");

        show("⭐ Sevimlilar", `
            <h3>Saqlangan vositalar</h3>
            <div id="favoriteList"></div>
        `);

        function drawFavorites() {
            const box = document.querySelector("#favoriteList");

            if (favorites.length === 0) {
                box.textContent = "Hozircha sevimli vositalar yo‘q.";
                return;
            }

            box.innerHTML = favorites.map((item, i) => `
                <div class="result">
                    ${item}
                    <button data-open="${i}">Ochish</button>
                    <button data-remove="${i}">O‘chirish</button>
                </div>
            `).join("");

            document.querySelectorAll("[data-open]").forEach(btn => {
                btn.onclick = () => openTool(favorites[btn.dataset.open]);
            });

            document.querySelectorAll("[data-remove]").forEach(btn => {
                btn.onclick = () => {
                    favorites.splice(btn.dataset.remove, 1);
                    localStorage.setItem("osonro_favorites", JSON.stringify(favorites));
                    drawFavorites();
                };
            });
        }


        
        drawFavorites();
    }

        else if (name === "eslatmalar") {
            show("🔔 Eslatmalar", `
                <textarea id="note" placeholder="Eslatma yozing..."></textarea>
                <button id="save">Saqlash</button>
                <div class="result" id="result"></div>
            `);
            document.querySelector("#note").value=localStorage.getItem("osonro_note")||"";
            document.querySelector("#save").onclick=()=>{
                localStorage.setItem("osonro_note",document.querySelector("#note").value);
                document.querySelector("#result").textContent="Eslatma saqlandi!";
            };
        }

    

    else if (name === "matematika testi") {
        show("🧠 Matematika testi", `
            <h2>Qiyinlik darajasini tanlang</h2>
            <button id="easy">🟢 Oson</button>
            <button id="medium">🟡 O‘rtacha</button>
            <button id="hard">🔴 Qiyin</button>
            <div id="game"></div>
        `);


        
        let savol = 0;
        let ball = 0;
        let javob = 0;
        let daraja = "";

        function boshlash(level) {
            daraja = level;
            savol = 0;
            ball = 0;
            yangiSavol();
        }

        function yangiSavol() {
            const game = document.querySelector("#game");

            if (savol >= 10) {
                game.innerHTML = `
                    <h2>Test tugadi! 🎉</h2>
                    <h2>Natija: ${ball}/10</h2>
                    <button id="again">Qaytadan boshlash</button>
                `;
                document.querySelector("#again").onclick = () => {
                    game.innerHTML = `
                        <button id="easy">🟢 Oson</button>
                        <button id="medium">🟡 O‘rtacha</button>
                        <button id="hard">🔴 Qiyin</button>
                    `;
                    ulash();
                };
                return;
            }



            
            let a, b, amal;

            if (daraja === "easy") {
                a = Math.floor(Math.random() * 20) + 1;
                b = Math.floor(Math.random() * 20) + 1;
                amal = Math.random() < 0.5 ? "+" : "-";
            } else if (daraja === "medium") {
                a = Math.floor(Math.random() * 12) + 2;
                b = Math.floor(Math.random() * 10) + 2;
                amal = Math.random() < 0.5 ? "×" : "÷";
                if (amal === "÷") {
                    a = a * b;
                }
            } else {
                a = Math.floor(Math.random() * 50) + 10;
                b = Math.floor(Math.random() * 20) + 2;
                amal = ["+", "-", "×"][Math.floor(Math.random() * 3)];
            }

            if (amal === "+") javob = a + b;
            if (amal === "-") javob = a - b;
            if (amal === "×") javob = a * b;
            if (amal === "÷") javob = a / b;

            game.innerHTML = `
                <h3>${savol + 1}/10-savol</h3>
                <h2>${a} ${amal} ${b} = ?</h2>
                <div id="options"></div>
                <div id="feedback" class="result"></div>
                <button id="next" style="display:none">Keyingi savol</button>
            `;
    
            let options = [
                javob,
                javob + 2,
                javob - 3,
                javob + 5
            ].sort(() => Math.random() - 0.5);

            document.querySelector("#options").innerHTML = options.map(x =>
                `<button class="answer">${x}</button>`
            ).join("");

            document.querySelectorAll(".answer").forEach(btn => {
                btn.onclick = () => {
                    if (document.querySelector("#next").style.display !== "none") return;

                    if (Number(btn.textContent) === javob) {
                        ball++;
                        document.querySelector("#feedback").textContent = "To‘g‘ri! 🎉";
                    } else {
                        document.querySelector("#feedback").textContent =
                            "Noto‘g‘ri! Javob: " + javob;
                    }

                    document.querySelector("#next").style.display = "inline-block";
                };
            });

            document.querySelector("#next").onclick = () => {
                savol++;
                yangiSavol();
            };
        }

        function ulash() {
            document.querySelector("#easy").onclick = () => boshlash("easy");
            document.querySelector("#medium").onclick = () => boshlash("medium");
            document.querySelector("#hard").onclick = () => boshlash("hard");
        }

        ulash();
    }


        else if (name === "kod muharriri") {
            show("💻 HTML kod muharriri", `
                <textarea id="code" rows="7" placeholder="<h1>Salom OSONRO</h1>"></textarea>
                <button id="go">Ishga tushirish</button>
                <iframe id="frame" sandbox="allow-scripts" style="width:100%;height:200px;background:white;margin-top:15px;border:0"></iframe>
            `);

            document.querySelector("#go").onclick = () => {
                document.querySelector("#frame").srcdoc =
                    document.querySelector("#code").value;
            };
        }

        else if (name === "ovoz yozish") {
            show("🎙️ Ovoz yozish", `
                <button id="start">Yozishni boshlash</button>
                <button id="stop">To‘xtatish</button>
                <div id="result" class="result">Mikrofon ruxsatini so‘rashi mumkin.</div>
            `);
            let recorder, chunks=[];
            document.querySelector("#start").onclick=async()=>{
                try{
                    const stream=await navigator.mediaDevices.getUserMedia({audio:true});
                    chunks=[];
                    recorder=new MediaRecorder(stream);
                    recorder.ondataavailable=e=>chunks.push(e.data);
                  recorder.onstop = () => {
    const audioBlob = new Blob(audioChunks, {
        type: "audio/webm"
    });

    const audioURL = URL.createObjectURL(audioBlob);

    document.querySelector("#recordingResult").innerHTML = `
        <h3>Your Recording</h3>
        <audio controls src="${audioURL}"></audio>
        <p>Ovozing yozib olindi.</p>
    `;

    stream.getTracks().forEach(track => track.stop());
};
                    recorder.start();
                    document.querySelector("#result").textContent="Yozilmoqda...";
                }catch{document.querySelector("#result").textContent="Mikrofon ruxsati berilmadi yoki mavjud emas.";}
            };
            document.querySelector("#stop").onclick=()=>{if(recorder&&recorder.state==="recording")recorder.stop();};
        }

        else if (name === "ob-havo") {
            show("🌤️ Ob-havo", `
                <input id="city" placeholder="Shahar nomi, masalan Tashkent">
                <button id="go">Ob-havoni ko‘rish</button>
                <div class="result" id="result">Shahar nomini kiriting.</div>
            `);
            document.querySelector("#go").onclick=async()=>{
                const city=document.querySelector("#city").value.trim();
                if(!city)return;
                const box=document.querySelector("#result");
                box.textContent="Yuklanmoqda...";
                try{
                    const geo=await fetch("https://geocoding-api.open-meteo.com/v1/search?name="+encodeURIComponent(city)+"&count=1&language=uz&format=json");
                    const gd=await geo.json();
                    if(!gd.results?.length)throw Error();
                    const place=gd.results[0];
                    const res=await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${place.latitude}&longitude=${place.longitude}&current=temperature_2m,relative_humidity_2m,wind_speed_10m`);
                    const data=await res.json();
                    box.textContent=`${place.name}: ${data.current.temperature_2m}°C | Namlik: ${data.current.relative_humidity_2m}% | Shamol: ${data.current.wind_speed_10m} km/soat`;
                }catch{box.textContent="Ob-havo ma'lumotini olib bo‘lmadi.";}
            };
        }

        else if (name === "valyuta") {
            show("💱 Valyuta konvertori", `
                <input id="amount" type="number" placeholder="Miqdor">
                <select id="currency"><option value="USD">USD → UZS</option><option value="EUR">EUR → UZS</option><option value="RUB">RUB → UZS</option></select>
                <button id="go">Hisoblash</button>${result}
            `);
            document.querySelector("#go").onclick=async()=>{
                const box=document.querySelector("#result");
                box.textContent="Kurs olinmoqda...";
                try{
                    const c=document.querySelector("#currency").value;
                    const r=await fetch("https://open.er-api.com/v6/latest/"+c);
                    const d=await r.json();
                    if(d.result!=="success")throw Error();
                    const amount=Number(document.querySelector("#amount").value);
                    box.textContent=`${(amount*d.rates.UZS).toLocaleString("uz-UZ")} so‘m (kurs: ${d.rates.UZS})`;
                }catch{box.textContent="Valyuta kursini olib bo‘lmadi.";}
            };
        }

else if (name === "ielts preparation") {
    show("🎓 IELTS Preparation", `
        <h2>Choose IELTS Section</h2>
        <button class="ieltsType" data-type="listening">🎧 Listening</button>
        <button class="ieltsType" data-type="reading">📖 Reading</button>
        <button class="ieltsType" data-type="writing">✍️ Writing</button>
        <button class="ieltsType" data-type="speaking">🗣️ Speaking</button>
        <div id="ieltsContent"></div>
    `);

    const box = document.querySelector("#ieltsContent");

    const questions = [
        ["Where is the woman going?", ["London", "Oxford", "Manchester"], 0],
        ["What time does the train leave?", ["9:00", "9:30", "10:00"], 1],
        ["How many people are coming?", ["Two", "Three", "Four"], 2],
        ["What is the man's job?", ["Teacher", "Doctor", "Driver"], 0],
        ["Which day is the meeting?", ["Monday", "Tuesday", "Friday"], 1],
        ["What does the woman want to buy?", ["A book", "A phone", "A bag"], 0],
        ["Where is the hotel?", ["Near the station", "Near the park", "Near the airport"], 2],
        ["How much is the ticket?", ["£10", "£15", "£20"], 1],
        ["What is the weather like?", ["Sunny", "Rainy", "Snowy"], 0],
        ["What is the man's favourite subject?", ["Maths", "English", "History"], 2],
        ["Where do they meet?", ["At school", "At the cafe", "At the library"], 1],
        ["What colour is the car?", ["Red", "Blue", "Black"], 2],
        ["What time does the shop close?", ["5 pm", "6 pm", "7 pm"], 1],
        ["Which sport does he play?", ["Football", "Tennis", "Basketball"], 0],
        ["What does she drink?", ["Tea", "Coffee", "Juice"], 2],
        ["Where is the museum?", ["In the city centre", "Near the beach", "Outside town"], 0],
        ["How does he travel to work?", ["By bus", "By car", "By train"], 1],
        ["What is her name?", ["Anna", "Sarah", "Emma"], 2],
        ["How long is the course?", ["Two weeks", "Four weeks", "Six weeks"], 1],
        ["What does he need?", ["A passport", "A ticket", "A map"], 0],
        ["Where are they going?", ["The cinema", "The theatre", "The museum"], 0],
        ["What is the room number?", ["12", "15", "18"], 2],
        ["Which language does she study?", ["French", "Spanish", "German"], 1],
        ["What is the price?", ["£25", "£30", "£35"], 2],
        ["When is the appointment?", ["Morning", "Afternoon", "Evening"], 0],
        ["What does he order?", ["Pizza", "Pasta", "Salad"], 1],
        ["Where does she live?", ["London", "Bristol", "Oxford"], 2],
        ["How many students are there?", ["15", "20", "25"], 1],
        ["What is his hobby?", ["Reading", "Swimming", "Cooking"], 0],
        ["Which bus should they take?", ["Bus 10", "Bus 15", "Bus 20"], 1],
        ["What does she want to study?", ["Science", "Art", "Music"], 0],
        ["Where is the bank?", ["Next to the shop", "Opposite the school", "Behind the hotel"], 2],
        ["What time is the flight?", ["8:15", "9:15", "10:15"], 0],
        ["Which animal does he like?", ["Cats", "Dogs", "Birds"], 1],
        ["What will they do tomorrow?", ["Go shopping", "Visit a park", "Watch a film"], 2]
    ];

    let current = 0;
    let score = 0;
    let answered = false;
function startListening() {
   const questions = [
    { q: "What is the primary purpose of the research mentioned in the lecture?", a: ["To challenge an existing theory", "To introduce a new scientific method", "To examine the effects of climate change"], c: 0 },
    { q: "Why did the university decide to modify its admission requirements?", a: ["To reduce administrative costs", "To attract a more diverse range of applicants", "To increase the number of international students"], c: 1 },
    { q: "What does the speaker suggest about technological development?", a: ["It always improves productivity", "Its benefits depend on how it is implemented", "It has eliminated the need for human skills"], c: 1 },
    { q: "According to the speaker, what is the main disadvantage of urban expansion?", a: ["The decline in agricultural land", "The increase in public transport", "The reduction of commercial activity"], c: 0 },
    { q: "What conclusion did the researchers reach?", a: ["The evidence was insufficient", "The original hypothesis was fully supported", "The results contradicted previous findings"], c: 2 },
    { q: "Why was the historical building renovated?", a: ["To accommodate additional offices", "To preserve its cultural significance", "To increase its commercial value"], c: 1 },
    { q: "What does the lecturer identify as a major barrier to effective communication?", a: ["A lack of technical equipment", "Differences in cultural expectations", "Insufficient vocabulary"], c: 1 },
    { q: "How does the speaker describe the new environmental policy?", a: ["Ambitious but difficult to implement", "Unnecessary and excessively expensive", "Simple and immediately effective"], c: 0 },
    { q: "What is the main reason for the decline in traditional industries?", a: ["Changes in consumer preferences", "A shortage of qualified workers", "Increased international competition"], c: 2 },
    { q: "What does the professor imply about the experiment?", a: ["Its findings should be interpreted cautiously", "It provides conclusive evidence", "It should be repeated without modification"], c: 0 },
    { q: "Why are some experts concerned about artificial intelligence?", a: ["It consumes too much electricity", "It may reproduce existing social inequalities", "It cannot process large amounts of information"], c: 1 },
    { q: "What factor contributed most significantly to the project's success?", a: ["The availability of financial resources", "The involvement of local communities", "The use of advanced equipment"], c: 1 },
    { q: "What is the speaker's attitude towards remote education?", a: ["Entirely positive", "Strongly opposed", "Generally favourable but cautious"], c: 2 },
    { q: "What problem did the research team encounter?", a: ["Inconsistent data collection", "A lack of theoretical background", "Unexpected government restrictions"], c: 0 },
    { q: "What does the speaker mean by sustainable development?", a: ["Economic growth without environmental limits", "Meeting present needs without harming future generations", "Prioritising industrial production over conservation"], c: 1 },
    { q: "Why did the company change its marketing strategy?", a: ["Its previous approach failed to reach younger consumers", "Its production costs had increased", "Its competitors had left the market"], c: 0 },
    { q: "What is the central argument of the lecture?", a: ["Economic growth is independent of education", "Education plays a crucial role in social mobility", "Social mobility is determined exclusively by income"], c: 1 },
    { q: "What limitation of the survey is mentioned?", a: ["The sample was not sufficiently representative", "The questions were too straightforward", "The survey lasted too long"], c: 0 },
    { q: "What does the speaker say about biodiversity?", a: ["It is unaffected by human activity", "Its decline can disrupt entire ecosystems", "It is only important in tropical regions"], c: 1 },
    { q: "What is the most likely consequence of the proposed changes?", a: ["A temporary reduction in efficiency", "An immediate increase in employment", "The complete removal of financial risks"], c: 0 },
    { q: "Why did the participants disagree with the initial proposal?", a: ["It lacked sufficient practical detail", "It was too expensive to evaluate", "It contradicted international regulations"], c: 0 },
    { q: "What does the lecturer emphasise about historical evidence?", a: ["It must be considered within its context", "It should always be accepted literally", "It is less reliable than modern statistics"], c: 0 },
    { q: "What is the speaker's main criticism of the study?", a: ["It overlooked important variables", "It relied on too many participants", "It used outdated technology"], c: 0 },
    { q: "Which factor is considered essential for successful language acquisition?", a: ["Memorising grammatical rules exclusively", "Consistent exposure and meaningful practice", "Avoiding communication until fluent"], c: 1 },
    { q: "What does the speaker predict about the labour market?", a: ["Demand for adaptable skills will increase", "Traditional occupations will disappear completely", "Professional qualifications will become irrelevant"], c: 0 }
];
    questions.sort(() => Math.random() - 0.5);

    let index = 0;
    let score = 0;

    function showQuestion() {
        if (index >= questions.length) {
            box.innerHTML = `
                <h2>Listening finished!</h2>
                <h3>Your score: ${score}/35</h3>
                <button id="restartListening">Try again</button>
            `;

            document.querySelector("#restartListening").onclick = startListening;
            return;
        }

        const item = questions[index];

        box.innerHTML = `
            <h3>Question ${index + 1}/35</h3>
            <p>${item.q}</p>
            ${item.a.map((answer, i) => `
                <button class="listenAnswer" data-index="${i}">
                    ${answer}
                </button>
            `).join("")}
            <p>Score: ${score}</p>
        `;

        speechSynthesis.cancel();

        const voice = new SpeechSynthesisUtterance(item.q);
        voice.lang = "en-US";
        speechSynthesis.speak(voice);

        document.querySelectorAll(".listenAnswer").forEach(btn => {
            btn.onclick = () => {
                if (Number(btn.dataset.index) === item.c) {
                    score++;
                }

                index++;
                showQuestion();
            };
        });
    }

    showQuestion();
}

    function renderQuestion() {
        answered = false;
        const q = questions[current];

        box.innerHTML = `
            <h2>🎧 Listening</h2>
            <h3>Question ${current + 1}/35</h3>
            <button id="playAudio">🔊 Play Question</button>
            <div id="questionArea"></div>
            <button id="nextQuestion" disabled>Next Question ➜</button>
        `;

        document.querySelector("#playAudio").onclick = () => {
            speechSynthesis.cancel();

            const audio = new SpeechSynthesisUtterance(q[0]);
            audio.lang = "en-US";
            audio.rate = 0.85;

            audio.onend = () => {
                document.querySelector("#questionArea").innerHTML = `
                    <h3>${q[0]}</h3>
                    ${q[1].map((option, i) => `
                        <button class="ieltsOption" data-answer="${i}">
                            ${String.fromCharCode(65 + i)}. ${option}
                        </button>
                    `).join("")}
                    <p id="feedback"></p>
                `;

                document.querySelectorAll(".ieltsOption").forEach(btn => {
                    btn.onclick = () => {
                        if (answered) return;
                        answered = true;

                        if (Number(btn.dataset.answer) === q[2]) {
                            score++;
                            document.querySelector("#feedback").textContent = "Correct! ✅";
                        } else {
                            document.querySelector("#feedback").textContent =
                                "Incorrect. Correct answer: " + q[1][q[2]];
                        }

                        document.querySelector("#nextQuestion").disabled = false;
                    };
                });
            };

            speechSynthesis.speak(audio);
        };

        document.querySelector("#nextQuestion").onclick = () => {
            if (!answered) return;

            current++;

            if (current < questions.length) {
                renderQuestion();
            } else {
                box.innerHTML = `
                    <h2>🎉 Listening Test Finished!</h2>
                    <h2>Score: ${score}/35</h2>
                    <button id="restartTest">🔄 Try Again</button>
                `;

                document.querySelector("#restartTest").onclick = startListening;
            }
        };
    }

    document.querySelectorAll(".ieltsType").forEach(btn => {
        btn.onclick = () => {
            const type = btn.dataset.type;
            speechSynthesis.cancel();

            if (type === "listening") {
                startListening();
            }

 
else if (type === "reading") {
    const passages = [
        {
            title: "The Evolution of Artificial Intelligence",
            text: `Artificial intelligence has transformed numerous industries over the past decades. Initially, computer systems were designed to perform narrowly defined tasks, following instructions explicitly provided by programmers. However, advances in machine learning have enabled systems to identify patterns, make predictions and improve their performance through experience.

Despite these developments, artificial intelligence remains far from possessing human-like understanding. Many systems rely on statistical relationships rather than genuine comprehension. Consequently, they may produce convincing answers while failing to recognise factual inconsistencies.

Researchers argue that the future development of artificial intelligence should prioritise transparency and accountability. Without appropriate safeguards, automated decisions could reinforce existing inequalities, particularly in employment, education and financial services.`,
            questions: [
                {
                    q: "What distinguishes modern machine learning systems from earlier computer systems?",
                    a: ["They can improve through experience", "They always understand human language", "They no longer require programming"],
                    c: 0
                },
                {
                    q: "What limitation of artificial intelligence is highlighted?",
                    a: ["It cannot perform statistical calculations", "It may identify patterns without genuine understanding", "It is unable to process large datasets"],
                    c: 1
                },
                {
                    q: "What concern do researchers express about automated decisions?",
                    a: ["They may reinforce existing inequalities", "They will eliminate all human employment", "They are always financially inefficient"],
                    c: 0
                },
                {
                    q: "Which statement best represents the passage?",
                    a: ["AI has already achieved human-level intelligence", "AI development offers benefits but requires responsible oversight", "Traditional computer systems are more reliable in every situation"],
                    c: 1
                },
                {
                    q: "The word 'transparency' most closely refers to:",
                    a: ["The ability to operate without electricity", "The openness of processes and decisions", "The speed of technological development"],
                    c: 1
                }
            ]
        },
        {
            title: "Urbanisation and the Future of Cities",
            text: `Urbanisation is frequently associated with economic growth, improved employment opportunities and access to essential services. Nevertheless, the rapid expansion of cities can create considerable challenges. Housing shortages, traffic congestion and pressure on public infrastructure are increasingly common in densely populated areas.

Some urban planners argue that sustainable development requires more than constructing additional buildings and roads. They emphasise the importance of accessible public transport, green spaces and mixed-use neighbourhoods. Such approaches may reduce dependence on private vehicles while improving residents' quality of life.

However, implementing these policies is not always straightforward. Financial limitations, political disagreements and competing interests can delay long-term planning. Therefore, successful urban development depends on cooperation between governments, businesses and local communities.`,
            questions: [
                {
                    q: "What is one consequence of rapid urban expansion?",
                    a: ["Reduced demand for public infrastructure", "Increased pressure on housing and transport", "The disappearance of employment opportunities"],
                    c: 1
                },
                {
                    q: "Why do planners support mixed-use neighbourhoods?",
                    a: ["They can improve accessibility and reduce car dependence", "They completely eliminate population growth", "They make public transport unnecessary"],
                    c: 0
                },
                {
                    q: "What can prevent sustainable urban policies from being implemented?",
                    a: ["An absence of urban populations", "Financial and political difficulties", "Excessive availability of green spaces"],
                    c: 1
                },
                {
                    q: "What is the author's main argument?",
                    a: ["Urban growth should be stopped entirely", "Sustainable cities require coordinated long-term planning", "Road construction is the only solution to congestion"],
                    c: 1
                },
                {
                    q: "The word 'competing' in the final paragraph suggests interests that:",
                    a: ["Are identical", "Are in conflict with one another", "Are no longer relevant"],
                    c: 1
                }
            ]
        }
    ];

    let passageIndex = Math.floor(Math.random() * passages.length);
    let current = passages[passageIndex];
    let index = 0;
    let score = 0;

    function showReadingQuestion() {
        if (index >= current.questions.length) {
            box.innerHTML = `
                <h2>Reading completed!</h2>
                <h3>Score: ${score}/${current.questions.length}</h3>
                <button id="readingAgain">New passage</button>
            `;

            document.querySelector("#readingAgain").onclick = () => {
                startReadingAgain();
            };
            return;
        }

        const item = current.questions[index];

        box.innerHTML = `
            <h2>${current.title}</h2>
            <p>${current.text}</p>
            <hr>
            <h3>Question ${index + 1}/${current.questions.length}</h3>
            <p>${item.q}</p>
            ${item.a.map((answer, i) => `
                <button class="readingAnswer" data-index="${i}">
                    ${answer}
                </button>
            `).join("")}
            <p>Score: ${score}</p>
        `;

        document.querySelectorAll(".readingAnswer").forEach(btn => {
            btn.onclick = () => {
                if (Number(btn.dataset.index) === item.c) {
                    score++;
                }

                index++;
                showReadingQuestion();
            };
        });
    }

    function startReadingAgain() {
        passageIndex = (passageIndex + 1) % passages.length;
        current = passages[passageIndex];
        index = 0;
        score = 0;
        showReadingQuestion();
    }

    showReadingQuestion();
}


 
else if (type === "writing") {
    const tasks = [
        {
            type: "Task 2",
            title: "Technology and Education",
            question: "Some people believe that technology has made education more effective, while others argue that it has reduced the quality of learning. Discuss both views and give your own opinion."
        },
        {
            type: "Task 2",
            title: "Environmental Protection",
            question: "Some people think that protecting the environment is the responsibility of governments, while others believe individuals should take action. Discuss both views and give your opinion."
        },
        {
            type: "Task 2",
            title: "Working from Home",
            question: "Working from home is becoming increasingly common. Do the advantages of this development outweigh the disadvantages?"
        },
        {
            type: "Task 2",
            title: "Artificial Intelligence",
            question: "Artificial intelligence is changing the way people work and communicate. Do you think this development is mostly positive or negative?"
        },
        {
            type: "Task 2",
            title: "University Education",
            question: "Some people believe university education should be free for everyone. To what extent do you agree or disagree?"
        },
        {
            type: "Task 2",
            title: "Social Media",
            question: "Social media has a significant influence on modern society. What are the advantages and disadvantages of this influence?"
        }
    ];

    let taskIndex = Math.floor(Math.random() * tasks.length);
    let currentTask = tasks[taskIndex];

    box.innerHTML = `
        <h2>✍️ IELTS Writing</h2>
        <h3>${currentTask.type}: ${currentTask.title}</h3>
        <p>${currentTask.question}</p>

        <textarea id="writingText"
            placeholder="Write your essay here..."
            style="width:100%;min-height:220px;padding:12px;">
        </textarea>

        <p>Words: <span id="wordCount">0</span></p>

        <button id="checkWriting">Check Writing</button>
        <button id="newWriting">New Topic</button>

        <div id="writingResult"></div>
    `;

    const writingText = document.querySelector("#writingText");

    writingText.oninput = () => {
        const words = writingText.value.trim()
            ? writingText.value.trim().split(/\s+/).length
            : 0;

        document.querySelector("#wordCount").textContent = words;
    };

    document.querySelector("#checkWriting").onclick = () => {
        const text = writingText.value.trim();
        const words = text ? text.split(/\s+/).length : 0;

        let feedback = [];

        if (words < 250) {
            feedback.push("❌ Write at least 250 words for Task 2.");
        } else {
            feedback.push("✅ Word count requirement reached.");
        }

        if (!/[.!?]$/.test(text)) {
            feedback.push("❌ Check your final punctuation.");
        }

        if (!/[A-Z]/.test(text[0] || "")) {
            feedback.push("❌ Start with a capital letter.");
        }

        if (text.includes("  ")) {
            feedback.push("❌ Remove unnecessary double spaces.");
        }

        if (!/\b(however|moreover|furthermore|therefore|nevertheless)\b/i.test(text)) {
            feedback.push("💡 Try using academic linking words.");
        }

        document.querySelector("#writingResult").innerHTML =
            "<h3>Writing Feedback</h3>" +
            feedback.map(item => `<p>${item}</p>`).join("");
    };

    document.querySelector("#newWriting").onclick = () => {
        taskIndex = (taskIndex + 1) % tasks.length;
        currentTask = tasks[taskIndex];
        openTool("ielts preparation");
    };
}

else if (type === "speaking") {
    const topics = [
        {
            name: "Technology",
            part1: [
                "How often do you use technology in your daily life?",
                "What technological device could you not live without?",
                "Do you think older people find technology difficult to use?"
            ],
            part2: "Describe a piece of technology that has significantly changed your life. You should say what it is, when you started using it, how you use it and explain why it is important to you.",
            part3: [
                "How has technology changed the way people communicate?",
                "Do you think artificial intelligence will replace human workers?",
                "What are the potential disadvantages of depending too much on technology?"
            ]
        },
        {
            name: "Education",
            part1: [
                "What subject did you enjoy most at school?",
                "Do you prefer studying alone or with other people?",
                "What makes someone a good teacher?"
            ],
            part2: "Describe a skill you would like to learn in the future. You should say what the skill is, why you want to learn it, how you would learn it and explain how it could benefit your future.",
            part3: [
                "Should universities focus more on practical skills?",
                "How might education change in the next twenty years?",
                "Is online learning as effective as traditional classroom learning?"
            ]
        },
        {
            name: "Environment",
            part1: [
                "Do you enjoy spending time in nature?",
                "What environmental problems are common in your area?",
                "Do you recycle things at home?"
            ],
            part2: "Describe an environmental problem that concerns you. You should say what the problem is, where it occurs, what causes it and explain what could be done to solve it.",
            part3: [
                "Should governments or individuals take greater responsibility for environmental protection?",
                "How can cities become more environmentally friendly?",
                "Do you think economic development and environmental protection can coexist?"
            ]
        },
        {
            name: "Success",
            part1: [
                "What does success mean to you?",
                "Do you usually set goals for yourself?",
                "Do you think success requires hard work?"
            ],
            part2: "Describe a person you consider successful. You should say who this person is, what they have achieved, what qualities they possess and explain why you admire them.",
            part3: [
                "Is success mainly determined by talent or hard work?",
                "Does society put too much pressure on young people to succeed?",
                "How has the definition of success changed over time?"
            ]
        },
        {
            name: "Travel",
            part1: [
                "Do you enjoy travelling?",
                "Would you prefer travelling alone or with friends?",
                "What place would you like to visit?"
            ],
            part2: "Describe a memorable journey you would like to take. You should say where you would go, who you would travel with, what you would do there and explain why this journey would be memorable.",
            part3: [
                "How does tourism affect local communities?",
                "Should international travel be encouraged?",
                "What are the advantages of learning about different cultures?"
            ]
        }
    ];

    const topic = topics[Math.floor(Math.random() * topics.length)];
    let recorder;
    let audioChunks = [];
    let stream;

    box.innerHTML = `
        <h2>🎤 IELTS Speaking</h2>
        <h3>${topic.name}</h3>

        <h3>Part 1 — Introduction</h3>
        ${topic.part1.map((q, i) => `<p>${i + 1}. ${q}</p>`).join("")}

        <hr>

        <h3>Part 2 — Long Turn</h3>
        <p>${topic.part2}</p>
        <p>Try to speak for 1–2 minutes.</p>

        <hr>

        <h3>Part 3 — Discussion</h3>
        ${topic.part3.map((q, i) => `<p>${i + 1}. ${q}</p>`).join("")}

        <button id="startRecording">🎙️ Start Recording</button>
        <button id="stopRecording" disabled>⏹ Stop Recording</button>

        <div id="recordingResult"></div>
    `;

    document.querySelector("#startRecording").onclick = async () => {
        try {
            if (recorder && recorder.state === "recording") return;

            stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            audioChunks = [];

            recorder = new MediaRecorder(stream);

            recorder.ondataavailable = event => {
                if (event.data.size > 0) {
                    audioChunks.push(event.data);
                }
            };

            recorder.onstop = () => {
                const audioBlob = new Blob(audioChunks, {
                    type: "audio/webm"
                });

                const audioURL = URL.createObjectURL(audioBlob);

                document.querySelector("#recordingResult").innerHTML = `
                    <h3>Recording saved!</h3>
                    <audio controls src="${audioURL}"></audio>
                    <p>You can listen to your answer.</p>
                `;

                stream.getTracks().forEach(track => track.stop());
            };

            recorder.start();

            document.querySelector("#startRecording").disabled = true;
            document.querySelector("#stopRecording").disabled = false;
        } catch (error) {
            alert("Microphone permission is required!");
        }
    };

    document.querySelector("#stopRecording").onclick = () => {
        if (recorder && recorder.state === "recording") {
            recorder.stop();
            document.querySelector("#startRecording").disabled = false;
            document.querySelector("#stopRecording").disabled = true;
        }
    };
}

        }
    });
}


else if (name === "tarjimon") {
    show("🌍 Tarjimon", `
        <textarea id="source" rows="4" placeholder="Matn kiriting"></textarea>
        <select id="lang">
            <option value="en">Ingliz tiliga</option>
            <option value="ru">Rus tiliga</option>
            <option value="uz">O‘zbek tiliga</option>
        </select>
        <button id="go">Tarjima qilish</button>
        <div class="result" id="result"></div>
    `);

    document.querySelector("#go").onclick = async () => {
        const text = document.querySelector("#source").value.trim();
        if (!text) return;

        const box = document.querySelector("#result");
        box.textContent = "Tarjima qilinmoqda...";

        try {
            const lang = document.querySelector("#lang").value;
            const url = "https://api.mymemory.translated.net/get?q=" +
                encodeURIComponent(text) + "&langpair=uz|" + lang;

            const r = await fetch(url);
            const d = await r.json();
            box.textContent = d.responseData.translatedText;
        } catch {
            box.textContent = "Tarjima xizmatiga ulanib bo‘lmadi.";
        }
    };
}
    
else {
    show(name, `
        <div class="result">
            Bu bo‘limning to‘liq funksiyasini keyingi versiyada ulaymiz.
        </div>
    `);
}}